<!doctype>
<html>
<head>
    <meta charset="utf-8">
    <title>
        <?php echo $__env->yieldContent('title'); ?>
    </title>
</head>
<body>
 <?php echo $__env->yieldContent('body'); ?>
</body>
</html>