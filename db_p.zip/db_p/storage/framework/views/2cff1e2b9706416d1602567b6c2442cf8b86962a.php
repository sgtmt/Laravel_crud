<?php $__env->startSection('title'); ?>
input
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<form action="res" method="post">
<input type="input" name="id">

<input type="submit" value="SEND">
<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>