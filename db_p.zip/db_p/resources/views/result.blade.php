@php
    $title = __('users');
@endphp

@extends('layouts.app')
@section('content')
<h1>{{ $title }}</h1>
<h1>該当数：{{ $allCount}}件中{{$count}}件該当</h1>
<div class="table-responsive">
    <table class="table table-striped">
        <thead>
            <tr>
                <th>{{ __('ID') }}</th>
                <th>{{ __('Name') }}</th>
                <th>{{ __('Email') }}</th>
                <th>{{ __('Pass') }}</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($users as $user)
            
                <tr>
                    <td>{{ $user->id }}</td>
                    <td><a href="{{ url('users/'.$user->id) }}">{{ $user->name }}</a></td>
                    <td>{{ $user->email }}</td>
                    <td>{{ $user->password }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>
</div>
<?php
if($count == 0){
    echo"DB内に該当データなし";
}
?>
@endsection