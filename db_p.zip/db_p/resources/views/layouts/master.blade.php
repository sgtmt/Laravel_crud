<!doctype>
<html>
<head>
    <meta charset="utf-8">
    <title>
        @yield('title')
    </title>
</head>
<body>
 @yield('body')
</body>
</html>