@extends('layouts.master')

@section('title')
input
@stop

@section('body')
<form action="res" method="post">
<input type="input" name="id">

<input type="submit" value="SEND">
<input type="hidden" name="_token" value="{{csrf_token()}}">
</form>
@stop