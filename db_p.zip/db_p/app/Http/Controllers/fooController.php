<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class fooController extends Controller
{
    //
}
