<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\User;

use Illuminate\Support\Facades\Input;

class searchController extends Controller
{
    
    public function index(Request $request)
    {
        $data="";
        $id = Input::get('id');
          
        $users = DB::table('users')->where('id', '=', $id)
        ->get();
        $count = DB::table('users')->where('id', '=', $id)->count();
        $allCount = DB::table('users')->count();
        
        return view('result', ['users' => $users,'count'=>$count,'allCount'=>$allCount]);
    }
    public function form(){
        return view('formView');
    }
    // public function res(){

       
    //     // $email = Input::get('email');
    //     // $password = Input::get('password');

    //     return $id;
    // }

}